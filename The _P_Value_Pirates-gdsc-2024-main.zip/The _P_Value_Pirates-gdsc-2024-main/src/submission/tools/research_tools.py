### to search the Internet with DuckDuck
from langchain_community.tools import DuckDuckGoSearchRun
duckduckgo_tool = DuckDuckGoSearchRun()